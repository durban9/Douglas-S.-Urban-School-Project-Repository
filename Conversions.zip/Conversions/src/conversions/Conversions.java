/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conversions;

import java.util.Scanner;

/**
 *
 * @author DUrban
 */
public class Conversions {

    static Scanner input = new Scanner(System.in);
    static boolean UsingK;
    
    public static void main(String[] args) {
        
        int ConversionChoice=0;
        String KelvinChoice;
        
        System.out.println("Welcome to the English-to-Metric Converter!");
        System.out.println("On temp conversions, would you like the degrees"
                            + " Kelvin(K) to be displayed in the results "
                            + " as well? (Y/N): ");
       
        
       KelvinChoice=input.nextLine();
       if(!KelvinChoice.isEmpty() && 
                KelvinChoice.equalsIgnoreCase("Y")){
            UsingK=true;
            System.out.println("");
            System.out.println("You have chosen to display degrees "
                               + "Kelvin(K) in the results.");
            System.out.println("");
        } else {
            UsingK=false;
            System.out.println("");
            System.out.println("You have chosen not to display degrees "
                               + "Kelvin(K) in the results.");
            System.out.println("");
        }
       
        ConversionChoice=getCVType();
        
        while(ConversionChoice!=0){  
            switch (ConversionChoice) {
                case 1:
                    MiToKm();
                    break;
            
            
                case 2: 
                    InToCm();
                    break;
            
            
                case 3:
                    FtoC();
                    break;
            
            
                case 4:
                    CtoF();
                    break;
            
            
                default:
                    System.out.print("Sorry, but there is an error, please"
                                + " choose a conversion type.");
                    break;
        }
        
       //ConversionChoice=input.nextInt();
       ConversionChoice=getCVType();
       
    }     
    
       System.out.print("Thank you for using the English-to-Metric Converter!");
        
    }
    
    static int getCVType() {
        int ConversionSelection;
        
        do {
            try{
            System.out.println("Select your conversion type choice "
                               + "(1 = miles to kilometers, "
                               + "2 = inches to centimeters, "
                               + "3 = Fahrenheit to Celsius, "
                               + "4 = Celsius to Fahrenheit, "
                               + "0 = Exit the Program):");
            
        ConversionSelection=input.nextInt();
                if (ConversionSelection<0 || 
                        ConversionSelection>4){
                    System.out.println("I'm sorry, while you did choose "
                                       + "a number this time, it was not a "
                                       + "non-negative integer between "
                                       + "zero and four. Please try again.");
                    System.out.println("");
                }
            } catch (Exception e){
                System.out.println("I'm sorry, but your choices are the "
                        + "non-negative integers between zero and 4. Any user"
                        + " entry that exceeds these stated parameters will be "
                        + " met with this same message.");
                System.out.println("");
                input.nextLine();
                ConversionSelection=-1;
                
            }
        } while (ConversionSelection<0||
                 ConversionSelection>4);
            return ConversionSelection;
    } 
    

    static void MiToKm() {
        double Miles;
        double Kilometers;
    
    
      Miles=getValue("Miles");
      Kilometers=Miles*1.60934;
      System.out.println("When converted, " + Miles+ " miles equals " 
                         + Kilometers + " kilometers.");
      System.out.print("");
    }
    
    static void InToCm(){
        double Inches;
        double Centimeters;
        
      Inches=getValue("Inches");
      Centimeters=Inches*2.54;
      System.out.println("When converted, " + Inches + " inches equals " +
      Centimeters + " centimeters.");
      System.out.print("");
    }
    
    static void FtoC(){
        double Fahrenheit; 
        double Celsius;
        
        Fahrenheit=getValue("degrees in Fahrenheit");
        Celsius=((Fahrenheit-32) * 5.0/9.0);
        System.out.println("When converted, " + Fahrenheit + " degrees "
                        + "Fahrenheit equals " + Celsius + " degrees Celsius.");
        System.out.print("");
        if (UsingK){
            showDegreesK(Celsius);
        }
    }
    
    static void CtoF(){
        double Celsius;
        double Fahrenheit;
        
        Celsius=getValue("degrees in Celsius");
        Fahrenheit=((9.0/5.0)*Celsius)+32;
        
        System.out.println("When converted, " + Celsius + " degrees Celsius" +
                         " equals " + Fahrenheit + " degrees Fahrenheit.");
        System.out.print("");
        if(UsingK){
            showDegreesK(Celsius);
        }
    }

    
    public static double getValue(String ConversionType){
        double v=0;
        boolean badval;
        
        do{
           try{
               System.out.println("Please enter the amount of "  
                       + ConversionType + " to be converted.");
               System.out.print("");
               v=input.nextDouble();
               badval=false;
           } catch (Exception e) {
               System.out.println("I'm sorry, but that is not an acceptable"
                       + " input amount for conversion.");
               System.out.print("");
               input.nextLine();
               badval=true;
           }
        } while (badval);
            return v;
        
    } 
    
    static void showDegreesK(double TemperatureInCelsius){
        double TemperatureInKelvin;
        TemperatureInKelvin=TemperatureInCelsius+273.15;
        if(TemperatureInKelvin<0){
            System.out.println("Sorry, but the temperature in Kelvin cannot be"
                    + " displayed because it is below 0 K.");
            System.out.print("");
        } else{
            System.out.println("When converted to Kelvin, " + 
                                TemperatureInCelsius + " Celsius equals " + 
                                + TemperatureInKelvin + " Kelvin.");
            System.out.print("");
        }
    }
    
}


